#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define NUM_TALLAS 8

void RellenaMatriz(int **M, int n, int p)
{
   int i, j;

   for(i=0; i<n; i++)
      for(j=0; j<n; j++)
         M[i][j]=p;
}

int RellenaVector(int *V, int n, int x){
  
  for(int i = 0; i < n; i++) {
    V[i] = x;
  }
}

int **CreaMatriz(int n)
{

  int **M = NULL;
   // Reservamos espacio para las n filas (espacio para n punteros a entero)
   M = (int **)malloc(n * sizeof(int *));

   // A continuación, para cada fila, reservamos espacio para las m columnas
   for (int i = 0; i < n; i++)
      M[i] = (int *)malloc(n * sizeof(int));

   return M;

}

int *CreaVector(int n){

   int *V = (int*) malloc(n*sizeof(int));

   return V;
}

void LiberaMatriz(int **M, int n)
{
for (int i = 0; i < n; i++)
   {
      free(M[i]);
   }
   free(M);
}

void LiberaVector(int *V, int n){
   free(V);
}


int JuevesB(int **A, int *V, int n, int p)
{
   int i=0;
   int j=0;
   int k=0;
   int suma=0;
   int total=0;
   bool seguir = true;
   while (k<n && seguir == true)
   {
      k++;
      if (V[k]==p){
         seguir = false;
      }
   }
   
   if (seguir == true){
      for (i=n-k+1;i<n;i++){
         suma = 0;
         for (j=1; j<n; j++){
            suma+=A[i][j]*V[j];
         }
         total+=suma;
      }
   }
   
   return total;
}

int main()
{
 int i, j, talla, repite, nflops;
 int **A=NULL, *B=NULL;
 double tiempo_total_MC, tiempo_total_PC;
 clock_t tiempo_inicial_MC, tiempo_final_MC;
 clock_t tiempo_inicial_PC, tiempo_final_PC;

 int Vtallas[NUM_TALLAS] = {100,200,300,400,500,600,700,800};
 int Vrepite[NUM_TALLAS] = {10, 10, 10, 10, 10, 10, 10, 10};

 printf("\n\nExamen laboratorio 1 UO286277 Gustavo Sobrado Aller\n\n");
printf("Tiempo empleado:\n\n\n");
printf("\t\tTalla\t\tTiempo MC\t\tTiempo PC\n");
printf("\t\t-----\t\t---------\t\t---------\n");

for (i = 0; i < NUM_TALLAS; i++)
{
   talla = Vtallas[i];
   repite = Vrepite[i];
   nflops = talla * talla * talla;

   A = CreaMatriz(talla);
   B = CreaVector(talla);

   RellenaMatriz(A, talla, 10);
   RellenaVector(B, talla, 20);

   // Mejor caso
   tiempo_inicial_MC = clock();
   for (j = 0; j < repite; j++)
   {
      JuevesB(A, B, talla, 1000000000);
    }
    tiempo_final_MC=clock();

    //Peor caso
    tiempo_inicial_PC=clock();
    for (j = 0; j < repite; j++){
      JuevesB(A, B, talla, 1000000000);
    }
    tiempo_final_PC=clock();

    tiempo_total_MC = (tiempo_final_MC-tiempo_inicial_MC) / (double)CLOCKS_PER_SEC / repite;
    tiempo_total_PC = (tiempo_final_PC-tiempo_inicial_PC) / (double)CLOCKS_PER_SEC / repite;

    printf("\t\t%d\t\t%f\t\t%f\n", talla, tiempo_total_MC, tiempo_total_PC);

    LiberaMatriz(A, talla);
    LiberaVector(B, talla);

    A=NULL; B=NULL;
  }
  return 0;
}